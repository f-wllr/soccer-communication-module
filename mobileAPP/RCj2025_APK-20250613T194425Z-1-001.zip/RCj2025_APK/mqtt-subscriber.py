#pip install paho-mqtt --break-system-packages

import json
import socket # Just so we can properly handle hostname exceptions
import obspython as obs
import paho.mqtt.client as mqtt
import ssl
import pathlib


# Meta
__version__ = '1.0.0'
__version_info__ = (1, 0, 0)
__license__ = "AGPLv3"
__license_info__ = {
    "AGPLv3": {
        "product": "subscribe_mqtt_",
        "users": 0, # 0 being unlimited
        "customer": "Unsupported",
        "version": __version__,
        "license_format": "1.0",
    }
}
__author__ = 'Martin Faltus'

__doc__ = """\
Subscribe for selected MQTT topic and display it as text
"""

# Default values for the configurable options:
MQTT_HOST = "localhost" # Hostname of your MQTT server
MQTT_USER = ""
MQTT_PW = ""
MQTT_PORT = 1883 # Default MQTT port is 1883
MQTT_TOPIC = ""
SOURCE_NAME = ""
MQTT_TLS = False

last_payload = ""

# MQTT Event Functions
def on_mqtt_connect(client, userdata, flags, rc):
    """
    Called when the MQTT client is connected from the server.  Just prints a
    message indicating we connected successfully.
    """
    print("MQTT connection successful")
    
    set_config()

def on_mqtt_disconnect(client, userdata, rc):
    """
    Called when the MQTT client gets disconnected.  Just logs a message about it
    (we'll auto-reconnect inside of update_status()).
    """
    print("MQTT disconnected.  Reason: {}".format(str(rc)))

def on_mqtt_message(client, userdata, message):
    """
    Handles MQTT messages that have been subscribed to
    """
    global SOURCE_NAME
    global last_payload
    
    topic = pathlib.PurePosixPath(message.topic)
    payload = str(message.payload.decode("utf-8"))
    print(message.topic + ": " + payload)
    
    if payload != last_payload:
        source = obs.obs_get_source_by_name(SOURCE_NAME)
        if source is not None:
            settings = obs.obs_data_create()
            obs.obs_data_set_string(settings, "text", payload)
            obs.obs_source_update(source, settings)
            obs.obs_data_release(settings)
            obs.obs_source_release(source)

        last_payload = payload

# OBS Script Function Exports
def script_description():
    return __doc__ # We wrote a nice docstring...  Might as well use it!

def script_load(settings):
    """
    Just prints a message indicating that the script was loaded successfully.
    """
    print("MQTT script loaded.")

def script_unload():
    """
    Publishes a final status message indicating OBS is off
    (so your MQTT sensor doesn't get stuck thinking you're
    recording/streaming forever) and calls `CLIENT.disconnect()`.
    """
    if CLIENT.is_connected():
        CLIENT.disconnect()
    CLIENT.loop_stop()
##############################################################
def script_defaults(settings):
    """
    Sets up our default settings in the OBS Scripts interface.
    """
    obs.obs_data_set_default_string(settings, "mqtt_host", MQTT_HOST)
    obs.obs_data_set_default_string(settings, "mqtt_user", MQTT_USER)
    obs.obs_data_set_default_string(settings, "mqtt_pw", MQTT_PW)
    obs.obs_data_set_default_string(settings, "mqtt_topic", MQTT_TOPIC)
    obs.obs_data_set_default_int(settings, "mqtt_port", MQTT_PORT)
    obs.obs_data_set_default_bool(settings, "mqtt_tls", MQTT_TLS)

def script_properties():
    """
    Makes this script's settings configurable via OBS's Scripts GUI.
    """
    props = obs.obs_properties_create()
    obs.obs_properties_add_text(props, "mqtt_host", "MQTT server hostname", obs.OBS_TEXT_DEFAULT)
    obs.obs_properties_add_int(props, "mqtt_port", "MQTT TCP/IP port", MQTT_PORT, 65535, 1)
    obs.obs_properties_add_text(props, "mqtt_user", "MQTT username", obs.OBS_TEXT_DEFAULT)
    obs.obs_properties_add_text(props, "mqtt_pw", "MQTT password", obs.OBS_TEXT_PASSWORD)
    obs.obs_properties_add_bool(props, "mqtt_tls", "TLS/SSL")
    obs.obs_properties_add_text(props, "mqtt_topic", "MQTT topic   rcj_soccer/",obs.OBS_TEXT_DEFAULT)   
        
    #source list of text
    p = obs.obs_properties_add_list(props, "source", "Text Source", obs.OBS_COMBO_TYPE_EDITABLE, obs.OBS_COMBO_FORMAT_STRING)
    
    sources = obs.obs_enum_sources()
    if sources is not None:
        for index, source in enumerate(sources):
            source_id = obs.obs_source_get_unversioned_id(source)
            if source_id == "text_gdiplus" or source_id == "text_ft2_source":
                name = obs.obs_source_get_name(source)
                obs.obs_property_list_add_string(p, name, name)         
    obs.source_list_release(sources)
    
    return props

def script_update(settings):
    """
    Applies any changes made to the MQTT settings in the OBS Scripts GUI then
    reconnects the MQTT client.
    """
    # Apply the new settings
    global MQTT_HOST
    global MQTT_USER
    global MQTT_PW
    global MQTT_PORT
    global MQTT_TOPIC
    global MQTT_TLS
    global SOURCE_NAME
    
    mqtt_host = obs.obs_data_get_string(settings, "mqtt_host")
    if mqtt_host != MQTT_HOST:
        MQTT_HOST = mqtt_host
    mqtt_user = obs.obs_data_get_string(settings, "mqtt_user")
    if mqtt_user != MQTT_USER:
        MQTT_USER = mqtt_user
    mqtt_pw = obs.obs_data_get_string(settings, "mqtt_pw")
    if mqtt_pw != MQTT_PW:
        MQTT_PW = mqtt_pw
    mqtt_port = obs.obs_data_get_int(settings, "mqtt_port")
    if mqtt_port != MQTT_PORT:
        MQTT_PORT = mqtt_port
    mqtt_topic = obs.obs_data_get_string(settings, "mqtt_topic")
    if mqtt_topic != MQTT_TOPIC:
        MQTT_TOPIC = mqtt_topic
    source_name = obs.obs_data_get_string(settings, "source")
    if source_name != SOURCE_NAME:
        SOURCE_NAME = source_name
    mqtt_tls = use_tls = obs.obs_data_get_bool(settings, "mqtt_tls")
    if mqtt_tls != MQTT_TLS:
        MQTT_TLS = mqtt_tls

    # Disconnect (if connected) and reconnect the MQTT client
    CLIENT.disconnect()
    try:
        if MQTT_PW != "" and MQTT_USER != "":
            CLIENT.username_pw_set(MQTT_USER, password=MQTT_PW)
        if MQTT_TLS:
            CLIENT.tls_set()
            CLIENT.tls_insecure_set(True)
            
        CLIENT.connect_async(MQTT_HOST, MQTT_PORT, 60)

    except (socket.gaierror, ConnectionRefusedError) as e:
        print("NOTE: Got a socket issue: %s" % e)
        pass # Ignore it for now

    CLIENT.loop_start()
    
    
def set_config():
    if MQTT_TOPIC != "":
        CLIENT.subscribe("rcj_soccer/" + MQTT_TOPIC)
        print("Subscribed to rcj_soccer/" + MQTT_TOPIC)

# Using a global MQTT client variable to keep things simple:
CLIENT = mqtt.Client()
CLIENT.on_connect = on_mqtt_connect
CLIENT.on_disconnect = on_mqtt_disconnect
CLIENT.on_message = on_mqtt_message
